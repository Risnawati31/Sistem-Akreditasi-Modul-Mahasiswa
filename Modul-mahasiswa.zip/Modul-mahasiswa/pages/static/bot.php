      </div>
        <?php include '../static/footer.php'; ?>
    </div>
    <?php include '../static/template-bot.php'; ?>
  </body>
</html>