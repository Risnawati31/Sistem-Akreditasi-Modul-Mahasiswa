<?php include '../static/top.php'; ?>
  <section class="content">
    ISINYA DISINI YA
  </section>
<?php include '../static/bot.php'; ?>
